from setuptools import setup, find_packages

setup(
    name='funcoesBasicas',
    version='0.1.0',
    description='Biblioteca de funções básicas para projetos Python',
    author='João Gabriel',
    packages=find_packages(),
    python_requires='>=3.6',
)
